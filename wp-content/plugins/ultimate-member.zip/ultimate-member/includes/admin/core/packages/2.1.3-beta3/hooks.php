<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'users_count213beta3'       => 'users_count213beta3',
	'metadata_per_user213beta3' => 'metadata_per_user213beta3',
	'metatable213beta3'         => 'metatable213beta3',
);